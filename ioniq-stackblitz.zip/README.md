# Ioniq — StackBlitz starter

Paket ini dibuat agar Ioniq dapat dicoba tanpa Termux. StackBlitz WebContainers menjalankan Node.js di browser.

## Struktur

- public/index.html — UI Ioniq starter
- server/server.js — backend Express + OpenAI
- package.json
- .env.example
- .stackblitzrc

## Menjalankan

1. Import/upload folder ini ke project Node.js/WebContainers di StackBlitz.
2. Pastikan dependencies selesai di-install.
3. Isi environment `OPENAI_API_KEY` dengan API key milikmu. Jangan taruh key di index.html.
4. Jalankan `npm start` bila belum otomatis.
5. Buka Preview.

Catatan: UI di paket ini adalah starter fungsional karena file index.html Ioniq versi terakhir belum tersedia sebagai attachment. Setelah index.html asli diunggah, backend dapat dipertahankan dan UI asli bisa dipasang kembali.

Untuk penggunaan produksi, jangan mengandalkan web search sebagai pengganti market-data provider khusus.
