import "dotenv/config";
import express from "express";
import multer from "multer";
import path from "node:path";
import { fileURLToPath } from "node:url";
import OpenAI from "openai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);

if (!process.env.OPENAI_API_KEY) {
  console.error("ERROR: OPENAI_API_KEY belum diisi.");
  process.exit(1);
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";
const ENABLE_WEB_SEARCH = String(process.env.OPENAI_ENABLE_WEB_SEARCH ?? "true").toLowerCase() === "true";
const MAX_IMAGES = Number(process.env.MAX_IMAGES || 6);
const MAX_FILE_SIZE = Number(process.env.MAX_IMAGE_SIZE_MB || 10) * 1024 * 1024;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { files: MAX_IMAGES, fileSize: MAX_FILE_SIZE },
  fileFilter: (_req, file, cb) =>
    file.mimetype.startsWith("image/") ? cb(null, true) : cb(new Error("Hanya file gambar yang diperbolehkan."))
});

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
const publicDir = path.join(__dirname, "..", "public");
app.use(express.static(publicDir));

const IONIQ_INSTRUCTIONS = `
Kamu adalah Ioniq, AI Market Intelligence dan Business Analysis Assistant.
Jawab dalam bahasa pengguna. Untuk pertanyaan kompleks, berikan analisis mendalam dengan heading, data/fakta, interpretasi, asumsi, risiko, skenario, dan kesimpulan.
Jangan mengarang harga, rasio, berita, laporan, volume, atau angka pasar.
Bedakan fakta dari interpretasi dan proyeksi.
Jika informasi terbaru dibutuhkan dan web search tersedia, gunakan web search.
Untuk gambar/chart, simpulkan hanya hal yang benar-benar terlihat.
Jangan menjanjikan keuntungan dan jangan menyatakan saham pasti naik/turun.
`;

const dataUrl = file => `data:${file.mimetype};base64,${file.buffer.toString("base64")}`;

app.get("/api/health", (_req, res) => res.json({ ok:true, service:"ioniq", model:MODEL, webSearch:ENABLE_WEB_SEARCH }));

app.post("/api/chat", upload.array("images", MAX_IMAGES), async (req, res) => {
  try {
    const prompt = typeof req.body.prompt === "string" ? req.body.prompt.trim() : "";
    const files = Array.isArray(req.files) ? req.files : [];
    if (!prompt && !files.length) return res.status(400).json({ error:"Prompt atau gambar diperlukan." });

    const content = [{ type:"input_text", text:prompt || "Analisis gambar yang saya kirim secara menyeluruh." }];
    for (const file of files) content.push({ type:"input_image", image_url:dataUrl(file), detail:"auto" });

    const response = await openai.responses.create({
      model: MODEL,
      instructions: IONIQ_INSTRUCTIONS,
      input: [{ role:"user", content }],
      tools: ENABLE_WEB_SEARCH ? [{ type:"web_search" }] : [],
      store:false
    });

    res.json({ reply:response.output_text?.trim() || "Model tidak mengembalikan teks.", model:MODEL, webSearch:ENABLE_WEB_SEARCH });
  } catch (error) {
    console.error(error);
    const status = Number.isInteger(error?.status) && error.status >= 400 ? error.status : 500;
    res.status(status).json({ error:"Gagal memproses permintaan Ioniq.", detail:process.env.NODE_ENV === "development" ? String(error?.message || error) : undefined });
  }
});

app.use((error, _req, res, _next) => {
  if (error instanceof multer.MulterError) return res.status(400).json({ error:error.message });
  if (error) return res.status(400).json({ error:error.message || "Request tidak valid." });
  res.status(500).json({ error:"Internal server error." });
});

// Express 5-compatible fallback:
app.use((_req, res) => res.sendFile(path.join(publicDir, "index.html")));

app.listen(PORT, "0.0.0.0", () => console.log(`Ioniq running on port ${PORT}`));
